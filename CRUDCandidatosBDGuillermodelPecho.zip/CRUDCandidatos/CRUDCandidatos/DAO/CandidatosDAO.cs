﻿using CRUD.Excepcion;
using CRUDCandidatos.BD;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CRUDCandidatos.DAO
{
    internal class CandidatoDAO
    {
        //ATRIBUTOS
        private Conexion conexion = new Conexion();
        public CandidatoDAO()
        {
        }

        public int agregarCandidato(Candidato pro)
        {
            int resul = 0;
            string strINSERT = "INSERT INTO candidatos (nombre, ciudad, trabaja, fechainscripcion) values (@nombre, @ciudad, @trabajo, @fechainscripcion);";
            try
            {
                MySqlCommand mCommand = new MySqlCommand(strINSERT, conexion.abrirConexion());
                mCommand.Parameters.Add(new MySqlParameter("@nombre", pro.Nombre));
                mCommand.Parameters.Add(new MySqlParameter("@ciudad", pro.Ciudad));
                mCommand.Parameters.Add(new MySqlParameter("@trabajo", pro.Trabaja));
                mCommand.Parameters.Add(new MySqlParameter("@fechainscripcion", pro.Fechainscripcion));

                resul = mCommand.ExecuteNonQuery();
                //if (resul!=0)     MessageBox.Show("OK");
                //else              MessageBox.Show("Fallo");

            }
            catch (MySqlException ex)
            {
                ExcepcionAlmacen e = new ExcepcionAlmacen();
                e.CodigoError = ex.ErrorCode;
                e.MensajeAdministrador = ex.Message;
                e.SentenciaSQL = strINSERT;
                switch (ex.Number)
                {
                    case 1062:
                        //CLAVE DUPLICADA
                        e.MensajeUsuario = "Clave duplicada";
                        break;
                }
            }
            finally
            {
                conexion.cerrarConexion();
            }
            return resul;
        }


        public int modificarCandidato(Candidato pro)
        {
            int resul = 0;
            string strUPDATE = " UPDATE candidatos " +
                   "SET nombre = @nombre, " +
                   "ciudad = @ciudad, " +
                   "trabaja = @trabaja, " +
                   "fechainscripcion = @fechainscripcion " +
                   "WHERE idcandidato = @idcandidato";
            try
            {
                MySqlCommand mCommand = new MySqlCommand(strUPDATE, conexion.abrirConexion());
                mCommand.Parameters.Add(new MySqlParameter("@nombre", pro.Nombre));
                mCommand.Parameters.Add(new MySqlParameter("@ciudad", pro.Ciudad));
                mCommand.Parameters.Add(new MySqlParameter("@trabaja", pro.Trabaja));
                mCommand.Parameters.Add(new MySqlParameter("@fechainscripcion", pro.Fechainscripcion));
                mCommand.Parameters.Add(new MySqlParameter("@idcandidato", pro.IdCandidato));
                resul = mCommand.ExecuteNonQuery();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message); //Si existe un error aquí muestra el mensaje
            }
            finally
            {
                conexion.cerrarConexion();
            }
            return resul;
        }

        public int eliminarCandidato(int id)
        {
            int resul = 0;
            string strDELETE = " DELETE FROM candidatos WHERE idcandidato=@idcandidato";
            try
            {
                MySqlCommand mCommand = new MySqlCommand(strDELETE, conexion.abrirConexion());
                mCommand.Parameters.Add(new MySqlParameter("@idcandidato", id));
                resul = mCommand.ExecuteNonQuery();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexion.cerrarConexion();
            }
            return resul;
        }
        public Candidato leerUno(int id)
        {
            MySqlDataReader mReader = null;
            Candidato p = new Candidato();
            string strCONSULTA = "SELECT * FROM candidatos WHERE idcandidato=@id";

            try
            {
                MySqlCommand mCommand = new MySqlCommand(strCONSULTA);
                mCommand.Parameters.Add(new MySqlParameter("@id", id));
                mCommand.Connection = conexion.abrirConexion();
                mReader = mCommand.ExecuteReader();

                while (mReader.Read())
                {
                    p.IdCandidato = mReader.GetInt16("idcandidato");
                    p.Nombre = mReader.GetString("nombre");
                    p.Ciudad = mReader.GetString("ciudad");
                    p.Trabaja = mReader.GetBoolean("trabaja");
                    p.Fechainscripcion = mReader.GetDateTime("fechainscripcion");
                }
                mReader.Close();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexion.cerrarConexion();
            }
            return p;
        }
        public List<Candidato> consultarCandidatos(String filtro)
        {
            List<Candidato> lisProductos = new List<Candidato>();
            MySqlDataReader mReader = null;
            Candidato p;
            string strCONSULTA = "SELECT * FROM candidatos";
            if (filtro != "")
            {
                strCONSULTA += " WHERE " +
                    "nombre LIKE '%" + filtro + "%' OR " +
                    "precio LIKE '%" + filtro + "%' OR " +
                    "cantidad LIKE '%" + filtro + "%';";
            }
            try
            {
                MySqlCommand mCommand = new MySqlCommand(strCONSULTA);
                mCommand.Connection = conexion.abrirConexion();
                mReader = mCommand.ExecuteReader();

                while (mReader.Read())
                {
                    p = new Candidato();
                    p.IdCandidato = mReader.GetInt16("idcandidato");
                    p.Nombre = mReader.GetString("nombre");
                    p.Ciudad = mReader.GetString("ciudad");
                    p.Trabaja = mReader.GetBoolean("trabaja");
                    //4 es la quinta col, empieza en 0
                    p.Fechainscripcion = mReader.GetDateTime("fechainscripcion");
                    lisProductos.Add(p);
                }
                mReader.Close();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexion.cerrarConexion();
            }
            return lisProductos;
        }
    }
}
