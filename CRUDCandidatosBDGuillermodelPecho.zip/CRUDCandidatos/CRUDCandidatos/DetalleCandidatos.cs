﻿using CRUDCandidatos.DAO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CRUDCandidatos
{
    public partial class DetalleCandidatos : Form
    {
        public int idCodigo;
        public String nombre;
        public String ciudad;
        public Boolean trabaja;
        public DateTime fechaInscripcion;
        public Boolean accion;
        CandidatoDAO cidadDAO;
        public DetalleCandidatos()
        {
            InitializeComponent();
            cidadDAO = new CandidatoDAO();

        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            Candidato candidato = new Candidato();
            candidato.IdCandidato = Convert.ToInt32(nudCodigo.Value);
            candidato.Nombre = txtNombre.Text;
            candidato.Ciudad = txtCiudad.Text;
            candidato.Trabaja = cbTrabaja.Checked;
            candidato.Fechainscripcion = dtpInscripcion.Value;
            cidadDAO.modificarCandidato(candidato);
            Close();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void DetalleCandidatos_Load(object sender, EventArgs e)
        {
            Candidato cs = cidadDAO.leerUno(idCodigo);
            nudCodigo.Value = idCodigo;
            txtNombre.Text = cs.Nombre;
            txtCiudad.Text = cs.Ciudad;
            cbTrabaja.Checked = cs.Trabaja;
            dtpInscripcion.Value = cs.Fechainscripcion;
        }
    }
}
