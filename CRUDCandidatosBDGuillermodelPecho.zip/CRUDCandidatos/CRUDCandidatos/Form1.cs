﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using CRUDCandidatos.DAO;
using CRUDCandidatos.Modelo;

namespace CRUDCandidatos
{
    public partial class Form1 : Form
    {
        List<Candidato> can = new List<Candidato>();
        CandidatoDAO canDAO = new CandidatoDAO();

        public Form1()
        {
            InitializeComponent();
            CargarListaCandidatos();

        }

        private void dgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        public void limpiarCampos()
        {
            nudCandidato.Value = 0;
            txtNombre.Clear();
            txtCiudad.Clear();
            cbxTrabaja.Checked= false;
            dtpIniciacion.Value=DateTime.Today;
        }

        private void btnAlta_Click(object sender, EventArgs e)
        {
            Candidato nuevo = new Candidato((int) nudCandidato.Value,txtNombre.Text,txtCiudad.Text,cbxTrabaja.Checked,dtpIniciacion.Value);
            canDAO.agregarCandidato(nuevo);
            ActualizarLista();
            limpiarCampos();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            
        }

        private int getIdIfExist()
        {
            if (!nudCandidato.Text.Trim().Equals(""))
            {
                if (int.TryParse(nudCandidato.Text.Trim(), out int id))
                    return id;
                else
                    return -1;
            }
            else
                return -1;
        }

        public void ActualizarLista()
        {
            CargarListaCandidatos();
            dgvCandidatos.DataSource = null;
            dgvCandidatos.DataSource = can;
            dgvCandidatos.ClearSelection();
        }

        public void CargarListaCandidatos()
        {
            //VACIO lista
            can.Clear();
            //Cargo la lista con la select
            can = canDAO.consultarCandidatos("");


            dgvCandidatos.DataSource = null;
            dgvCandidatos.DataSource = can;
            dgvCandidatos.ClearSelection();

            
        }

        private void dgvCandidatos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvCandidatos.Columns[e.ColumnIndex].Name == "Modificar")
            {
                int posicion = e.RowIndex;
                DetalleCandidatos Data = new DetalleCandidatos();
                Data.idCodigo = Convert.ToInt32(can[posicion].IdCandidato);
                Data.ShowDialog();
                limpiarCampos();
                CargarListaCandidatos();
            }

            if (dgvCandidatos.Columns[e.ColumnIndex].Name == "Eliminar")
            {
                int posicion = e.RowIndex;
                if (posicion != -1)
                {
                    DialogResult result;
                    result = MessageBox.Show("Esta seguro que desea eliminar", "Titulo", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                    switch (result)
                    {
                        case DialogResult.Yes:
                            canDAO.eliminarCandidato(can[posicion].IdCandidato);
                            ActualizarLista();
                            break;
                        case DialogResult.No:
                            break;
                        default:
                            break;
                    }
                }
            }
        }
    }
}
