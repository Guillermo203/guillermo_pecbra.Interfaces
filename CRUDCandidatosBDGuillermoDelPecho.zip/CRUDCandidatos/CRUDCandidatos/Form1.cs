﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using CRUDCandidatos.DAO;
using CRUDCandidatos.Modelo;

namespace CRUDCandidatos
{
    public partial class Form1 : Form
    {
        List<Candidato> can = new List<Candidato>();
        CandidatoDAO canDAO = new CandidatoDAO();

        public Form1()
        {
            InitializeComponent();

            
        }

        private void dgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        public void limpiarCampos()
        {
            nudCandidato.Value = 0;
            txtNombre.Clear();
            txtCiudad.Clear();
            cbxTrabaja.Checked= false;
            dtpIniciacion.Value=DateTime.Today;
        }

        private void btnAlta_Click(object sender, EventArgs e)
        {
            Candidato nuevo = new Candidato(Decimal.ToInt32(nudCandidato.Value),txtNombre.Text,txtCiudad.Text,cbxTrabaja.Checked,dtpIniciacion.Value);
            can.Add(nuevo);
            ActualizarLista();
            limpiarCampos();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            CargarListaCandidatos();
            
        }

        private int getIdIfExist()
        {
            if (!nudCandidato.Text.Trim().Equals(""))
            {
                if (int.TryParse(nudCandidato.Text.Trim(), out int id))
                    return id;
                else
                    return -1;
            }
            else
                return -1;
        }

        public void ActualizarLista()
        {
            dgvCandidatos.DataSource = null;
            dgvCandidatos.DataSource = can;
            dgvCandidatos.ClearSelection();
        }

        public void CargarListaCandidatos()
        {
            dgvCandidatos.Rows.Clear();
            dgvCandidatos.Refresh();
            //VACIO lista
            can.Clear();
            //Cargo la lista con la select
            can = canDAO.consultarCandidatos("");

            for (int i = 0; i < can.Count(); i++)
            {

                dgvCandidatos.RowTemplate.Height = Commun.ROW_HEIGTH;
                dgvCandidatos.Rows.Add(
                    can[i].IdCandidato,
                    can[i].Nombre,
                    can[i].Ciudad,
                    can[i].Trabaja,
                    can[i].Fechainscripcion);
            }
        }

        private void dgvCandidatos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dgvCandidatos.Columns[e.ColumnIndex].Name == "Modificar")
            {
                DetalleCandidatos Data = new DetalleCandidatos();
                limpiarCampos();
                CargarListaCandidatos();
            }

            if (dgvCandidatos.Columns[e.ColumnIndex].Name == "Eliminar")
            {

                int id;
                id = getIdIfExist();
                if (id == -1) return;
                if (MessageBox.Show("¿Desea eliminar el producto?", "Eliminar producto", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    if (canDAO.eliminarCandidato(id) != 0)
                    {
                        MessageBox.Show("Producto eliminado con éxito.");
                        CargarListaCandidatos();
                        limpiarCampos();
                    }
                    else
                    {
                        MessageBox.Show("Error al eliminar el producto.");
                    }
                }
            }
        }
    }
}
