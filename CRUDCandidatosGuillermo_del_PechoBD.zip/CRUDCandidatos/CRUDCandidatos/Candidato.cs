﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRUDCandidatos
{
    internal class Candidato
    {
        int idCandidato;
        string nombre;
        string ciudad;
        Boolean trabaja;
        DateTime fechainscripcion;

        public Candidato(int idCandidato1, string nombre, string ciudad, bool trabaja, DateTime fechainscripcion)
        {
            idCandidato = idCandidato1;
            this.Nombre = nombre;
            this.Ciudad = ciudad;
            this.Trabaja = trabaja;
            this.Fechainscripcion = fechainscripcion;
        }

        public int IdCandidato { get => idCandidato; set => idCandidato = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public string Ciudad { get => ciudad; set => ciudad = value; }
        public bool Trabaja { get => trabaja; set => trabaja = value; }
        public DateTime Fechainscripcion { get => fechainscripcion; set => fechainscripcion = value; }
    }
}
