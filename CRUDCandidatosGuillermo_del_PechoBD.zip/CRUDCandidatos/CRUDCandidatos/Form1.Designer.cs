﻿namespace CRUDCandidatos
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.lblTitulo = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblFecha = new System.Windows.Forms.Label();
            this.nudCandidato = new System.Windows.Forms.NumericUpDown();
            this.btnAlta = new System.Windows.Forms.Button();
            this.dtpIniciacion = new System.Windows.Forms.DateTimePicker();
            this.cbxTrabaja = new System.Windows.Forms.CheckBox();
            this.txtCiudad = new System.Windows.Forms.TextBox();
            this.lblCiudad = new System.Windows.Forms.Label();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.lnlNombre = new System.Windows.Forms.Label();
            this.IdCandidato = new System.Windows.Forms.Label();
            this.dgvCandidatos = new System.Windows.Forms.DataGridView();
            this.Modificar = new System.Windows.Forms.DataGridViewImageColumn();
            this.Eliminar = new System.Windows.Forms.DataGridViewImageColumn();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudCandidato)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCandidatos)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.BackColor = System.Drawing.Color.Transparent;
            this.lblTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.ForeColor = System.Drawing.Color.MediumSeaGreen;
            this.lblTitulo.Location = new System.Drawing.Point(66, 35);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(162, 31);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Candidatos";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.lblFecha);
            this.panel1.Controls.Add(this.nudCandidato);
            this.panel1.Controls.Add(this.btnAlta);
            this.panel1.Controls.Add(this.dtpIniciacion);
            this.panel1.Controls.Add(this.cbxTrabaja);
            this.panel1.Controls.Add(this.txtCiudad);
            this.panel1.Controls.Add(this.lblCiudad);
            this.panel1.Controls.Add(this.txtNombre);
            this.panel1.Controls.Add(this.lnlNombre);
            this.panel1.Controls.Add(this.IdCandidato);
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(72, 114);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1133, 246);
            this.panel1.TabIndex = 1;
            // 
            // lblFecha
            // 
            this.lblFecha.AutoSize = true;
            this.lblFecha.ForeColor = System.Drawing.Color.FloralWhite;
            this.lblFecha.Location = new System.Drawing.Point(436, 160);
            this.lblFecha.Name = "lblFecha";
            this.lblFecha.Size = new System.Drawing.Size(52, 13);
            this.lblFecha.TabIndex = 9;
            this.lblFecha.Text = "Iniciacion";
            // 
            // nudCandidato
            // 
            this.nudCandidato.Location = new System.Drawing.Point(142, 27);
            this.nudCandidato.Name = "nudCandidato";
            this.nudCandidato.Size = new System.Drawing.Size(835, 20);
            this.nudCandidato.TabIndex = 8;
            // 
            // btnAlta
            // 
            this.btnAlta.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnAlta.Location = new System.Drawing.Point(327, 195);
            this.btnAlta.Name = "btnAlta";
            this.btnAlta.Size = new System.Drawing.Size(566, 23);
            this.btnAlta.TabIndex = 3;
            this.btnAlta.Text = "Alta";
            this.btnAlta.UseVisualStyleBackColor = true;
            this.btnAlta.Click += new System.EventHandler(this.btnAlta_Click);
            // 
            // dtpIniciacion
            // 
            this.dtpIniciacion.CustomFormat = "dd-MM-yyyy";
            this.dtpIniciacion.Location = new System.Drawing.Point(503, 153);
            this.dtpIniciacion.Name = "dtpIniciacion";
            this.dtpIniciacion.Size = new System.Drawing.Size(335, 20);
            this.dtpIniciacion.TabIndex = 7;
            this.dtpIniciacion.Value = new System.DateTime(2025, 1, 20, 0, 0, 0, 0);
            // 
            // cbxTrabaja
            // 
            this.cbxTrabaja.AutoSize = true;
            this.cbxTrabaja.ForeColor = System.Drawing.Color.FloralWhite;
            this.cbxTrabaja.Location = new System.Drawing.Point(142, 153);
            this.cbxTrabaja.Name = "cbxTrabaja";
            this.cbxTrabaja.Size = new System.Drawing.Size(62, 17);
            this.cbxTrabaja.TabIndex = 6;
            this.cbxTrabaja.Text = "Trabaja";
            this.cbxTrabaja.UseVisualStyleBackColor = true;
            // 
            // txtCiudad
            // 
            this.txtCiudad.Location = new System.Drawing.Point(142, 104);
            this.txtCiudad.Name = "txtCiudad";
            this.txtCiudad.Size = new System.Drawing.Size(835, 20);
            this.txtCiudad.TabIndex = 5;
            // 
            // lblCiudad
            // 
            this.lblCiudad.AutoSize = true;
            this.lblCiudad.ForeColor = System.Drawing.Color.FloralWhite;
            this.lblCiudad.Location = new System.Drawing.Point(37, 107);
            this.lblCiudad.Name = "lblCiudad";
            this.lblCiudad.Size = new System.Drawing.Size(40, 13);
            this.lblCiudad.TabIndex = 4;
            this.lblCiudad.Text = "Ciudad";
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(142, 62);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(835, 20);
            this.txtNombre.TabIndex = 3;
            // 
            // lnlNombre
            // 
            this.lnlNombre.AutoSize = true;
            this.lnlNombre.ForeColor = System.Drawing.Color.FloralWhite;
            this.lnlNombre.Location = new System.Drawing.Point(37, 65);
            this.lnlNombre.Name = "lnlNombre";
            this.lnlNombre.Size = new System.Drawing.Size(44, 13);
            this.lnlNombre.TabIndex = 2;
            this.lnlNombre.Text = "Nombre";
            // 
            // IdCandidato
            // 
            this.IdCandidato.AutoSize = true;
            this.IdCandidato.ForeColor = System.Drawing.Color.FloralWhite;
            this.IdCandidato.Location = new System.Drawing.Point(37, 27);
            this.IdCandidato.Name = "IdCandidato";
            this.IdCandidato.Size = new System.Drawing.Size(64, 13);
            this.IdCandidato.TabIndex = 0;
            this.IdCandidato.Text = "IdCandidato";
            // 
            // dgvCandidatos
            // 
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.White;
            this.dgvCandidatos.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvCandidatos.BackgroundColor = System.Drawing.Color.SeaGreen;
            this.dgvCandidatos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCandidatos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Modificar,
            this.Eliminar});
            this.dgvCandidatos.Location = new System.Drawing.Point(72, 421);
            this.dgvCandidatos.Name = "dgvCandidatos";
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.BurlyWood;
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            this.dgvCandidatos.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvCandidatos.Size = new System.Drawing.Size(1133, 173);
            this.dgvCandidatos.TabIndex = 2;
            this.dgvCandidatos.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCandidatos_CellClick);
            this.dgvCandidatos.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_CellContentClick);
            // 
            // Modificar
            // 
            this.Modificar.HeaderText = "Modificar";
            this.Modificar.Image = ((System.Drawing.Image)(resources.GetObject("Modificar.Image")));
            this.Modificar.Name = "Modificar";
            this.Modificar.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Modificar.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // Eliminar
            // 
            this.Eliminar.HeaderText = "Eliminar";
            this.Eliminar.Image = ((System.Drawing.Image)(resources.GetObject("Eliminar.Image")));
            this.Eliminar.Name = "Eliminar";
            this.Eliminar.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Eliminar.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkOliveGreen;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1240, 620);
            this.Controls.Add(this.dgvCandidatos);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblTitulo);
            this.ForeColor = System.Drawing.Color.FloralWhite;
            this.Name = "Form1";
            this.Text = "CRUD Candidatos";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudCandidato)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCandidatos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Label lnlNombre;
        private System.Windows.Forms.Label IdCandidato;
        private System.Windows.Forms.TextBox txtCiudad;
        private System.Windows.Forms.Label lblCiudad;
        private System.Windows.Forms.DateTimePicker dtpIniciacion;
        private System.Windows.Forms.CheckBox cbxTrabaja;
        private System.Windows.Forms.DataGridView dgvCandidatos;
        private System.Windows.Forms.DataGridViewImageColumn Modificar;
        private System.Windows.Forms.DataGridViewImageColumn Eliminar;
        private System.Windows.Forms.Button btnAlta;
        private System.Windows.Forms.Label lblFecha;
        private System.Windows.Forms.NumericUpDown nudCandidato;
    }
}

